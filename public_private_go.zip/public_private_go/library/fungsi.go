package library

import "fmt"

func SayHello() {
	fmt.Println("Hello")
}

func Introduce(name string) {
	fmt.Println("Nama saya adalah ", name)
}
